package com.aeropassport.service;

import com.aeropassport.dto.AdminStatistics;
import com.aeropassport.dto.HardwareGenealogyReport;
import com.aeropassport.model.Module;
import com.aeropassport.model.Part;
import com.aeropassport.model.PartPassport;
import com.aeropassport.model.Supplier;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.aggregation.LookupOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReportService {

    private final MongoTemplate mongoTemplate;

    // ADMIN PRIVILEGDES

    // getting admin statistics 

    public AdminStatistics getAdminStatistics() {
        long suppliers = mongoTemplate.count(new Query(), Supplier.class);
        long parts = mongoTemplate.count(new Query(), Part.class);
        long flightReady = mongoTemplate.count(
                Query.query(Criteria.where("flightReadiness").is("Ready")),
                PartPassport.class
        );
        long underInspection = mongoTemplate.count(
                Query.query(Criteria.where("status").in("Inspected", "Under Inspection")),
                Part.class
        );
        long modules = mongoTemplate.count(new Query(), Module.class);

        log.info("[STATS] suppliers={}, parts={}, flightReady={}, underInspection={}, modules={}",
                suppliers, parts, flightReady, underInspection, modules);

        return AdminStatistics.builder()
                .totalSuppliers(suppliers)
                .totalParts(parts)
                .flightReadyPartsCount(flightReady)
                .partsUnderInspectionCount(underInspection)
                .totalModules(modules)
                .build();
    }

    // getting HW genealogy report for each part

    public Optional<HardwareGenealogyReport> getHardwareGenealogyReport(String partId) {
        log.info("[GENEALOGY] Generating report for part: {}", partId);

        LookupOperation lookupSupplier = LookupOperation.newLookup()
                .from("suppliers")
                .localField("supplierId")
                .foreignField("_id")
                .as("supplierList");

        LookupOperation lookupPassport = LookupOperation.newLookup()
                .from("part_passports")
                .localField("_id")
                .foreignField("partId")
                .as("passportList");

        LookupOperation lookupModule = LookupOperation.newLookup()
                .from("modules")
                .localField("_id")
                .foreignField("partIds")
                .as("moduleList");

        Aggregation aggregation = Aggregation.newAggregation(
                Aggregation.match(Criteria.where("_id").is(partId)),
                lookupSupplier,
                lookupPassport,
                lookupModule
        );

        AggregationResults<AggRow> results = mongoTemplate.aggregate(
                aggregation, "parts", AggRow.class
        );

        List<AggRow> rows = results.getMappedResults();
        if (rows.isEmpty()) {
            log.warn("[GENEALOGY] Part not found: {}", partId);
            return Optional.empty();
        }

        AggRow row = rows.get(0);

        Supplier supplier = (row.getSupplierList() != null && !row.getSupplierList().isEmpty())
                ? row.getSupplierList().get(0) : null;
        PartPassport passport = (row.getPassportList() != null && !row.getPassportList().isEmpty())
                ? row.getPassportList().get(0) : null;
        Module module = (row.getModuleList() != null && !row.getModuleList().isEmpty())
                ? row.getModuleList().get(0) : null;

        HardwareGenealogyReport.SupplierSummary supplierInfo = null;
        if (supplier != null) {
            supplierInfo = HardwareGenealogyReport.SupplierSummary.builder()
                    .id(supplier.getId())
                    .name(supplier.getName())
                    .country(supplier.getCountry())
                    .status(supplier.getStatus())
                    .build();
        }

        HardwareGenealogyReport.ModuleSummary moduleInfo = null;
        if (module != null) {
            moduleInfo = HardwareGenealogyReport.ModuleSummary.builder()
                    .id(module.getId())
                    .name(module.getName())
                    .type(module.getType())
                    .status(module.getStatus())
                    .build();
        }

        HardwareGenealogyReport report = HardwareGenealogyReport.builder()
                .partId(row.getId())
                .partName(row.getName())
                .category(row.getCategory())
                .batchNumber(row.getBatchNumber())
                .receivedDate(row.getReceivedDate())
                .status(row.getStatus())
                .supplier(supplierInfo)
                .currentModule(moduleInfo)
                .build();

        if (passport != null) {
            report.setFlightReadiness(passport.getFlightReadiness());
            report.setCertifications(passport.getCertifications());
            report.setInspections(passport.getInspections());
            report.setEvents(passport.getEvents());

            // COMPROMISED if anything failed, FLIGHT_READY if cleared, otherwise pending
            boolean failedEvent = passport.getEvents().stream()
                    .anyMatch(e -> "Failed".equalsIgnoreCase(e.getEventType()) ||
                                  "Failed".equalsIgnoreCase(e.getStatusAfterEvent()));
            boolean failedInspection = passport.getInspections().stream()
                    .anyMatch(i -> "Failed".equalsIgnoreCase(i.getResult()));

            if (failedEvent || failedInspection) {
                report.setOverallGenealogyStatus("COMPROMISED");
            } else if ("Ready".equalsIgnoreCase(passport.getFlightReadiness())) {
                report.setOverallGenealogyStatus("FLIGHT_READY");
            } else {
                report.setOverallGenealogyStatus("QUALIFICATION_PENDING");
            }
        } else {
            report.setFlightReadiness("Unknown");
            report.setCertifications(new ArrayList<>());
            report.setInspections(new ArrayList<>());
            report.setEvents(new ArrayList<>());
            report.setOverallGenealogyStatus("QUALIFICATION_PENDING");
        }

        return Optional.of(report);
    }

    // internal aggregation result structure
    @Data
    private static class AggRow {
        private String id;
        private String name;
        private String category;
        private String batchNumber;
        private Date receivedDate;
        private String status;

        private List<Supplier> supplierList;
        private List<PartPassport> passportList;
        private List<Module> moduleList;
    }
}
