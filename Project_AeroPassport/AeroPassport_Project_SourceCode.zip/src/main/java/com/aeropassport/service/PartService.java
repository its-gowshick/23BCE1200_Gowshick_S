package com.aeropassport.service;

import com.aeropassport.model.Event;
import com.aeropassport.model.Part;
import com.aeropassport.model.PartPassport;
import com.aeropassport.repository.PartPassportRepository;
import com.aeropassport.repository.PartRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

@Slf4j
@Service
@RequiredArgsConstructor
public class PartService {

    private final PartRepository partRepository;
    private final PartPassportRepository partPassportRepository;

    // registering part

    @Transactional
    public Part registerPart(Part part) {
        if (part.getId() == null || part.getId().trim().isEmpty()) {
            part.setId("PAR-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        }
        part.setReceivedDate(new Date());
        part.setStatus("Received");

        Part saved = partRepository.save(part);
        log.info("[AUDIT] Part registered: {} - {} (batch: {})", saved.getId(), saved.getName(), saved.getBatchNumber());

        Event receiveEvent = Event.builder()
                .eventType("Received")
                .timestamp(new Date())
                .remarks("Part received and logged in AeroPassport.")
                .statusAfterEvent("Received")
                .build();

        PartPassport pp = PartPassport.builder()
                .id("PAS-" + saved.getId())
                .partId(saved.getId())
                .certifications(new ArrayList<>())
                .flightReadiness("Not Ready")
                .remarks("Awaiting initial inspection and qualification.")
                .events(new ArrayList<>())
                .inspections(new ArrayList<>())
                .build();

        pp.getEvents().add(receiveEvent);
        partPassportRepository.save(pp);

        log.info("[AUDIT] Created passport {} for part {}", pp.getId(), saved.getId());

        return saved;
    }
}
