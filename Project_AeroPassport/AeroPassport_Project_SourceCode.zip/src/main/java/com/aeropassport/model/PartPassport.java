package com.aeropassport.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document(collection = "part_passports")
public class PartPassport {
    @Id
    private String id;

    @Indexed(unique = true, name = "passport_part_unique_idx")
    private String partId;

    @Builder.Default
    private List<String> certifications = new ArrayList<>();

    private String currentModuleId;
    private String flightReadiness; // Valid entries: Not Ready, Ready, Flown, Retired
    private String remarks;

    @Builder.Default
    private List<Inspection> inspections = new ArrayList<>();

    @Builder.Default
    private List<Event> events = new ArrayList<>();
}
