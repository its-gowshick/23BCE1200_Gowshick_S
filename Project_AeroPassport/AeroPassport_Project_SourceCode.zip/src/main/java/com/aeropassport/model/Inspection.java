package com.aeropassport.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Inspection {
    private String testType;
    private String result; // Valid entries: Passed, Failed
    private String inspector;
    private Date date;
    private String remarks;
}
