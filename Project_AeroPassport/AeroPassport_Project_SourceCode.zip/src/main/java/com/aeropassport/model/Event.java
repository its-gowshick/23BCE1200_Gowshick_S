package com.aeropassport.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Event {
    private String eventType; // Valid entries: Received, Inspected, Integrated, Launched, Recovered, Failed
    private Date timestamp;
    private String remarks;
    private String statusAfterEvent;
}
