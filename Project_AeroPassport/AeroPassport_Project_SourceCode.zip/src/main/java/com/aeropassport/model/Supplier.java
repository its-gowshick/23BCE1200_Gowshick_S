package com.aeropassport.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document(collection = "suppliers")
public class Supplier {
    @Id
    private String id;
    private String name;
    private String country;
    private String certificationLevel; // ex: AS9100, ISO9001
    private String status; // Valid entries: Active, Suspended
}
