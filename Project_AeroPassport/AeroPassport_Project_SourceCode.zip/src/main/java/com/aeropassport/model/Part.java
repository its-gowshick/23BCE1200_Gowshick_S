package com.aeropassport.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document(collection = "parts")
public class Part {
    @Id
    private String id;
    private String name;
    private String category; // ex: Sensor, Power, Communication, Recovery, Structural

    @Indexed(name = "part_supplier_idx")
    private String supplierId;

    @Indexed(name = "part_batch_idx")
    private String batchNumber;

    private Date receivedDate;
    private String status; // Valid entries: Received, Inspected, Integrated, Launched, Recovered, Failed
}
