package com.aeropassport.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document(collection = "modules")
public class Module {
    @Id
    private String id;
    private String name;
    private String type; // ex: Avionics, Propulsion, Structural, Recovery

    @Indexed(name = "module_parts_multikey_idx")
    @Builder.Default
    private List<String> partIds = new ArrayList<>();

    private String status; // Valid entries: Assembly, Testing, Flight-Ready, Decommissioned
}
