package com.aeropassport.dto;

import com.aeropassport.model.Event;
import com.aeropassport.model.Inspection;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class HardwareGenealogyReport {
    private String partId;
    private String partName;
    private String category;
    private String batchNumber;
    private Date receivedDate;
    private String status;

    private SupplierSummary supplier;
    private ModuleSummary currentModule;

    private String flightReadiness;
    private List<String> certifications;
    private List<Inspection> inspections;
    private List<Event> events;

    private String overallGenealogyStatus; // Valid entries: COMPROMISED, FLIGHT_READY, QUALIFICATION_PENDING

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class SupplierSummary {
        private String id;
        private String name;
        private String country;
        private String status;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class ModuleSummary {
        private String id;
        private String name;
        private String type;
        private String status;
    }
}
