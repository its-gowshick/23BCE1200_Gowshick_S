package com.aeropassport.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AdminStatistics {
    private long totalSuppliers;
    private long totalParts;
    private long flightReadyPartsCount;
    private long partsUnderInspectionCount;
    private long totalModules;
}
