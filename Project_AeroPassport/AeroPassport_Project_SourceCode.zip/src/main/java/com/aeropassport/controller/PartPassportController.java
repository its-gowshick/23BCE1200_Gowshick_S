package com.aeropassport.controller;

import com.aeropassport.model.Event;
import com.aeropassport.model.Inspection;
import com.aeropassport.model.Part;
import com.aeropassport.model.PartPassport;
import com.aeropassport.repository.PartPassportRepository;
import com.aeropassport.repository.PartRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Slf4j
@RestController
@RequestMapping("/api/passports")
@RequiredArgsConstructor
public class PartPassportController {

    private final PartPassportRepository partPassportRepository;
    private final PartRepository partRepository;

    // retrive all passports

    @GetMapping
    public ResponseEntity<List<PartPassport>> getAllPassports() {
        return ResponseEntity.ok(partPassportRepository.findAll());
    }

    // get passport by partId

    @GetMapping("/{partId}")
    public ResponseEntity<PartPassport> getPassportByPartId(@PathVariable String partId) {
        return partPassportRepository.findByPartId(partId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // adding inspection

    @PostMapping("/{partId}/inspections")
    public ResponseEntity<PartPassport> addInspection(
            @PathVariable String partId,
            @RequestBody Inspection inspection) {

        Optional<PartPassport> ppOpt = partPassportRepository.findByPartId(partId);
        Optional<Part> pOpt = partRepository.findById(partId);

        if (ppOpt.isEmpty() || pOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        PartPassport pp = ppOpt.get();
        Part p = pOpt.get();

        if (inspection.getDate() == null) {
            inspection.setDate(new Date());
        }

        pp.getInspections().add(inspection);

        String status = "Failed".equalsIgnoreCase(inspection.getResult()) ? "Failed" : "Inspected";
        p.setStatus(status);
        partRepository.save(p);

        Event evt = Event.builder()
                .eventType("Inspected")
                .timestamp(new Date())
                .remarks("Logged " + inspection.getTestType() + " inspection. Result: " +
                        inspection.getResult() + ". Inspector: " + inspection.getInspector())
                .statusAfterEvent(status)
                .build();
        pp.getEvents().add(evt);

        PartPassport saved = partPassportRepository.save(pp);
        log.info("[AUDIT] Inspection logged for part {}: {} -> {}", partId, inspection.getTestType(),
                inspection.getResult());

        return ResponseEntity.ok(saved);
    }

    // Updating flight readiness (used for GO/NO-GO decisions)

    @PutMapping("/{partId}/readiness")
    public ResponseEntity<PartPassport> updateFlightReadiness(
            @PathVariable String partId,
            @RequestParam String status,
            @RequestParam(required = false) String remarks) {

        Optional<PartPassport> ppOpt = partPassportRepository.findByPartId(partId);
        if (ppOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        PartPassport pp = ppOpt.get();
        pp.setFlightReadiness(status);
        if (remarks != null && !remarks.trim().isEmpty()) {
            pp.setRemarks(remarks);
        }

        Event evt = Event.builder()
                .eventType("ReadinessChange")
                .timestamp(new Date())
                .remarks("Flight readiness state changed to " + status + ". Remarks: " + remarks)
                .statusAfterEvent(status)
                .build();
        pp.getEvents().add(evt);

        PartPassport saved = partPassportRepository.save(pp);
        log.info("[AUDIT] Readiness for part {} set to {}", partId, status);

        return ResponseEntity.ok(saved);
    }

    // adding certifications for each part

    @PostMapping("/{partId}/certifications")
    public ResponseEntity<PartPassport> addCertification(
            @PathVariable String partId,
            @RequestParam String certification) {

        Optional<PartPassport> ppOpt = partPassportRepository.findByPartId(partId);
        if (ppOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        PartPassport pp = ppOpt.get();
        pp.getCertifications().add(certification);

        pp.getEvents().add(Event.builder()
                .eventType("Certified")
                .timestamp(new Date())
                .remarks("Added certification: " + certification)
                .statusAfterEvent(pp.getFlightReadiness())
                .build());

        PartPassport saved = partPassportRepository.save(pp);
        log.info("[AUDIT] Cert added for part {}: {}", partId, certification);

        return ResponseEntity.ok(saved);
    }
}
