package com.aeropassport.controller;

import com.aeropassport.model.Supplier;
import com.aeropassport.repository.SupplierRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/suppliers")
@RequiredArgsConstructor
public class SupplierController {

    private final SupplierRepository supplierRepository;
    private final MongoTemplate mongoTemplate;

    // adding suppliers - admin has the priviledge

    @PostMapping
    public ResponseEntity<Supplier> createSupplier(@RequestBody Supplier supplier) {
        Supplier saved = supplierRepository.save(supplier);
        log.info("[API] Supplier added: {} ({})", saved.getName(), saved.getId());
        return new ResponseEntity<>(saved, HttpStatus.CREATED);
    }

    // retrive all suppliers

    @GetMapping
    public ResponseEntity<List<Supplier>> getAllSuppliers() {
        return ResponseEntity.ok(supplierRepository.findAll());
    }

    // retrive by id

    @GetMapping("/{id}")
    public ResponseEntity<Supplier> getSupplierById(@PathVariable String id) {
        return supplierRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // update supplier details - admin has the priviledge

    @PutMapping("/{id}")
    public ResponseEntity<Supplier> updateSupplier(@PathVariable String id, @RequestBody Supplier supplierDetails) {
        return supplierRepository.findById(id)
                .map(existing -> {
                    existing.setName(supplierDetails.getName());
                    existing.setCountry(supplierDetails.getCountry());
                    existing.setCertificationLevel(supplierDetails.getCertificationLevel());
                    existing.setStatus(supplierDetails.getStatus());
                    Supplier updated = supplierRepository.save(existing);
                    log.info("[API] Supplier updated: {}", updated.getId());
                    return ResponseEntity.ok(updated);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // delete supplier - by admin only

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSupplier(@PathVariable String id) {
        if (!supplierRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        supplierRepository.deleteById(id);
        log.info("[API] Supplier {} deleted", id);
        return ResponseEntity.noContent().build();
    }

    // drop suppliers collection - by admin only

    @DeleteMapping
    public ResponseEntity<String> dropSuppliersCollection() {
        log.info("[ADMIN] Dropping suppliers collection");
        mongoTemplate.dropCollection(Supplier.class);
        return ResponseEntity.ok("Suppliers collection dropped successfully.");
    }
}
