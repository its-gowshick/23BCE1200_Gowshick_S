package com.aeropassport.controller;

import com.aeropassport.dto.AdminStatistics;
import com.aeropassport.dto.HardwareGenealogyReport;
import com.aeropassport.service.ReportService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class ReportController {

    private final ReportService reportService;

    // Core Feature: Creating HW Genealogy report (Tracebility) for each part

    @GetMapping("/parts/{partId}/genealogy")
    public ResponseEntity<HardwareGenealogyReport> getHardwareGenealogyReport(@PathVariable String partId) {
        log.info("[API] Genealogy report requested for part: {}", partId);
        return reportService.getHardwareGenealogyReport(partId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Admin can view: Admin statistics for DB overview

    @GetMapping("/admin/statistics")
    public ResponseEntity<AdminStatistics> getAdminStatistics() {
        return ResponseEntity.ok(reportService.getAdminStatistics());
    }
}
