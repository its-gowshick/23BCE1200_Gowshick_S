package com.aeropassport.controller;

import com.aeropassport.model.Supplier;
import com.aeropassport.model.Part;
import com.aeropassport.model.PartPassport;
import com.aeropassport.model.Module;
import com.aeropassport.model.Inspection;
import com.aeropassport.model.Event;
import com.aeropassport.repository.SupplierRepository;
import com.aeropassport.repository.PartRepository;
import com.aeropassport.repository.PartPassportRepository;
import com.aeropassport.repository.ModuleRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.index.Index;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class DatabaseAdminController {

        private final MongoTemplate mongoTemplate;
        private final SupplierRepository supplierRepository;
        private final PartRepository partRepository;
        private final PartPassportRepository partPassportRepository;
        private final ModuleRepository moduleRepository;

        @PostMapping("/reset")
        public ResponseEntity<String> resetDatabase() {
                log.info("[ADMIN] Resetting database...");

                // dropping the collections
                mongoTemplate.dropCollection(Supplier.class);
                mongoTemplate.dropCollection(Part.class);
                mongoTemplate.dropCollection(PartPassport.class);
                mongoTemplate.dropCollection(Module.class);

                // re-creating indexes after dropping
                mongoTemplate.indexOps(Part.class)
                                .ensureIndex(new Index().on("supplierId", Direction.ASC).named("part_supplier_idx"));
                mongoTemplate.indexOps(Part.class)
                                .ensureIndex(new Index().on("batchNumber", Direction.ASC).named("part_batch_idx"));
                mongoTemplate.indexOps(PartPassport.class).ensureIndex(
                                new Index().on("partId", Direction.ASC).named("passport_part_unique_idx").unique());
                mongoTemplate.indexOps(Module.class).ensureIndex(
                                new Index().on("partIds", Direction.ASC).named("module_parts_multikey_idx"));

                // seed data for suppliers
                Supplier orbitForge = Supplier.builder()
                                .id("SUP001")
                                .name("OrbitForge Components")
                                .country("India")
                                .certificationLevel("AS9100")
                                .status("Active")
                                .build();

                Supplier apexProp = Supplier.builder()
                                .id("SUP002")
                                .name("Apex Propulsion Labs")
                                .country("USA")
                                .certificationLevel("AS9100D")
                                .status("Active")
                                .build();

                Supplier solarisBatt = Supplier.builder()
                                .id("SUP003")
                                .name("Solaris Battery Systems")
                                .country("Germany")
                                .certificationLevel("ISO9001")
                                .status("Suspended")
                                .build();

                supplierRepository.saveAll(Arrays.asList(orbitForge, apexProp, solarisBatt));

                // seed data for parts
                Part imu = Part.builder()
                                .id("PAR001")
                                .name("MPU6050 IMU")
                                .category("Sensor")
                                .supplierId("SUP001")
                                .batchNumber("B2026-01")
                                .receivedDate(new Date(System.currentTimeMillis() - 86400000L * 5))
                                .status("Integrated")
                                .build();

                Part battery = Part.builder()
                                .id("PAR002")
                                .name("LCO-18650 Battery Pack")
                                .category("Power")
                                .supplierId("SUP003")
                                .batchNumber("B2026-BATT")
                                .receivedDate(new Date(System.currentTimeMillis() - 86400000L * 3))
                                .status("Failed")
                                .build();

                Part thruster = Part.builder()
                                .id("PAR003")
                                .name("Raptor Thruster Controller")
                                .category("Propulsion")
                                .supplierId("SUP002")
                                .batchNumber("B2026-PROP")
                                .receivedDate(new Date(System.currentTimeMillis() - 86400000L))
                                .status("Received")
                                .build();

                partRepository.saveAll(Arrays.asList(imu, battery, thruster));

                // seed data for modules
                Module avionics = Module.builder()
                                .id("MOD001")
                                .name("Avionics Flight Computer")
                                .type("Avionics")
                                .partIds(new ArrayList<>(List.of("PAR001")))
                                .status("Assembly")
                                .build();

                Module propulsion = Module.builder()
                                .id("MOD002")
                                .name("Main Stage Propulsion")
                                .type("Propulsion")
                                .partIds(new ArrayList<>())
                                .status("Testing")
                                .build();

                moduleRepository.saveAll(Arrays.asList(avionics, propulsion));

                // seed data for passports
                PartPassport imuPassport = PartPassport.builder()
                                .id("PAS-PAR001")
                                .partId("PAR001")
                                .certifications(new ArrayList<>(
                                                List.of("Vibration Spec Certified", "MIL-STD-810G Passed")))
                                .currentModuleId("MOD001")
                                .flightReadiness("Ready")
                                .remarks("IMU calibrated and mounted inside Avionics module.")
                                .inspections(new ArrayList<>(List.of(
                                                Inspection.builder()
                                                                .testType("Vibration Spec Verification")
                                                                .result("Passed")
                                                                .inspector("Gowshick")
                                                                .date(new Date(System.currentTimeMillis()
                                                                                - 86400000L * 4))
                                                                .remarks("Vibration amplitude tests passed within tolerance.")
                                                                .build(),
                                                Inspection.builder()
                                                                .testType("Functional Check")
                                                                .result("Passed")
                                                                .inspector("Gowshick")
                                                                .date(new Date(System.currentTimeMillis()
                                                                                - 86400000L * 4))
                                                                .remarks("I2C communication lines verified.")
                                                                .build())))
                                .events(new ArrayList<>(List.of(
                                                Event.builder()
                                                                .eventType("Received")
                                                                .timestamp(new Date(System.currentTimeMillis()
                                                                                - 86400000L * 5))
                                                                .remarks("Part received from OrbitForge.")
                                                                .statusAfterEvent("Received")
                                                                .build(),
                                                Event.builder()
                                                                .eventType("Inspected")
                                                                .timestamp(new Date(System.currentTimeMillis()
                                                                                - 86400000L * 4))
                                                                .remarks("Passed comprehensive functional checks.")
                                                                .statusAfterEvent("Inspected")
                                                                .build(),
                                                Event.builder()
                                                                .eventType("Integrated")
                                                                .timestamp(new Date(System.currentTimeMillis()
                                                                                - 86400000L * 2))
                                                                .remarks("Integrated into Avionics Flight Computer module.")
                                                                .statusAfterEvent("Integrated")
                                                                .build(),
                                                Event.builder()
                                                                .eventType("ReadinessChange")
                                                                .timestamp(new Date(
                                                                                System.currentTimeMillis() - 86400000L))
                                                                .remarks("Approved for flight readiness status.")
                                                                .statusAfterEvent("Ready")
                                                                .build())))
                                .build();

                PartPassport battPassport = PartPassport.builder()
                                .id("PAS-PAR002")
                                .partId("PAR002")
                                .certifications(new ArrayList<>())
                                .currentModuleId(null)
                                .flightReadiness("Not Ready")
                                .remarks("Defective battery cell detected during thermal checkout.")
                                .inspections(new ArrayList<>(List.of(
                                                Inspection.builder()
                                                                .testType("Thermal Vacuum Test")
                                                                .result("Failed")
                                                                .inspector("Gowshick")
                                                                .date(new Date(System.currentTimeMillis()
                                                                                - 86400000L * 2))
                                                                .remarks("Thermal vacuum test failed due to gas venting from battery cell.")
                                                                .build())))
                                .events(new ArrayList<>(List.of(
                                                Event.builder()
                                                                .eventType("Received")
                                                                .timestamp(new Date(System.currentTimeMillis()
                                                                                - 86400000L * 3))
                                                                .remarks("Part received from Solaris Battery Systems.")
                                                                .statusAfterEvent("Received")
                                                                .build(),
                                                Event.builder()
                                                                .eventType("Failed")
                                                                .timestamp(new Date(System.currentTimeMillis()
                                                                                - 86400000L * 2))
                                                                .remarks("Inspection failure reported in Thermal Vacuum test.")
                                                                .statusAfterEvent("Failed")
                                                                .build())))
                                .build();

                PartPassport thrusterPassport = PartPassport.builder()
                                .id("PAS-PAR003")
                                .partId("PAR003")
                                .certifications(new ArrayList<>())
                                .currentModuleId(null)
                                .flightReadiness("Not Ready")
                                .remarks("Awaiting initial testing.")
                                .inspections(new ArrayList<>())
                                .events(new ArrayList<>(List.of(
                                                Event.builder()
                                                                .eventType("Received")
                                                                .timestamp(new Date(
                                                                                System.currentTimeMillis() - 86400000L))
                                                                .remarks("Part logged in AeroPassport tracking system.")
                                                                .statusAfterEvent("Received")
                                                                .build())))
                                .build();

                partPassportRepository.saveAll(Arrays.asList(imuPassport, battPassport, thrusterPassport));

                log.info("[ADMIN] Database reset and seeded.");
                return ResponseEntity.ok("Database reset completed and seeded successfully with test records.");
        }
}
