package com.aeropassport.controller;

import com.aeropassport.model.Part;
import com.aeropassport.repository.PartPassportRepository;
import com.aeropassport.repository.PartRepository;
import com.aeropassport.service.PartService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/parts")
@RequiredArgsConstructor
public class PartController {

    private final PartService partService;
    private final PartRepository partRepository;
    private final PartPassportRepository partPassportRepository;
    private final MongoTemplate mongoTemplate;

    // CURD opr for parts

    @PostMapping
    public ResponseEntity<Part> registerPart(@RequestBody Part part) {
        Part registered = partService.registerPart(part);
        return new ResponseEntity<>(registered, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Part>> getAllParts() {
        return ResponseEntity.ok(partRepository.findAll());
    }

    // Read by id

    @GetMapping("/{id}")
    public ResponseEntity<Part> getPartById(@PathVariable String id) {
        return partRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // Read by supplier

    @GetMapping("/supplier/{supplierId}")
    public ResponseEntity<List<Part>> getPartsBySupplier(@PathVariable String supplierId) {
        return ResponseEntity.ok(partRepository.findBySupplierId(supplierId));
    }

    // Read by batch no.

    @GetMapping("/batch/{batchNumber}")
    public ResponseEntity<List<Part>> getPartsByBatch(@PathVariable String batchNumber) {
        return ResponseEntity.ok(partRepository.findByBatchNumber(batchNumber));
    }

    // Update part

    @PutMapping("/{id}")
    public ResponseEntity<Part> updatePart(@PathVariable String id, @RequestBody Part partDetails) {
        return partRepository.findById(id)
                .map(existing -> {
                    existing.setName(partDetails.getName());
                    existing.setCategory(partDetails.getCategory());
                    existing.setSupplierId(partDetails.getSupplierId());
                    existing.setBatchNumber(partDetails.getBatchNumber());
                    existing.setStatus(partDetails.getStatus());
                    Part updated = partRepository.save(existing);
                    log.info("[API] Part updated: {}", updated.getId());
                    return ResponseEntity.ok(updated);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    // Delete part

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePart(@PathVariable String id) {
        if (!partRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        partRepository.deleteById(id);

        // also clean up the passport if one exists
        partPassportRepository.findByPartId(id).ifPresent(pp -> {
            partPassportRepository.deleteById(pp.getId());
            log.info("[API] Deleted passport {} (cascade from part {})", pp.getId(), id);
        });

        log.info("[API] Part {} deleted", id);
        return ResponseEntity.noContent().build();
    }

    // Drop parts

    @DeleteMapping
    public ResponseEntity<String> dropPartsCollection() {
        log.info("[ADMIN] Dropping parts collection");
        mongoTemplate.dropCollection(Part.class);
        return ResponseEntity.ok("Parts collection dropped successfully.");
    }
}
