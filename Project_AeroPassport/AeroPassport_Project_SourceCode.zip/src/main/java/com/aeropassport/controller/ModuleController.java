package com.aeropassport.controller;

import com.aeropassport.model.Event;
import com.aeropassport.model.Module;
import com.aeropassport.model.Part;
import com.aeropassport.model.PartPassport;
import com.aeropassport.repository.ModuleRepository;
import com.aeropassport.repository.PartPassportRepository;
import com.aeropassport.repository.PartRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Slf4j
@RestController
@RequestMapping("/api/modules")
@RequiredArgsConstructor
public class ModuleController {

    private final ModuleRepository moduleRepository;
    private final PartRepository partRepository;
    private final PartPassportRepository partPassportRepository;
    private final MongoTemplate mongoTemplate;

    // CURD opr for Modules

    @PostMapping
    public ResponseEntity<Module> createModule(@RequestBody Module module) {
        Module saved = moduleRepository.save(module);
        log.info("[API] Module created: {}", saved.getId());
        return new ResponseEntity<>(saved, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Module>> getAllModules() {
        return ResponseEntity.ok(moduleRepository.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Module> getModuleById(@PathVariable String id) {
        return moduleRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Module> updateModule(@PathVariable String id, @RequestBody Module moduleDetails) {
        return moduleRepository.findById(id)
                .map(existing -> {
                    existing.setName(moduleDetails.getName());
                    existing.setType(moduleDetails.getType());
                    existing.setStatus(moduleDetails.getStatus());
                    existing.setPartIds(moduleDetails.getPartIds());
                    Module updated = moduleRepository.save(existing);
                    log.info("[API] Module updated: {}", updated.getId());
                    return ResponseEntity.ok(updated);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteModule(@PathVariable String id) {
        if (!moduleRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        moduleRepository.deleteById(id);
        log.info("[API] Module {} deleted", id);
        return ResponseEntity.noContent().build();
    }

    // part -> module assign

    @PostMapping("/{moduleId}/parts/{partId}")
    public ResponseEntity<Module> assignPartToModule(
            @PathVariable String moduleId,
            @PathVariable String partId) {

        Optional<Module> modOpt = moduleRepository.findById(moduleId);
        Optional<Part> pOpt = partRepository.findById(partId);
        Optional<PartPassport> ppOpt = partPassportRepository.findByPartId(partId);

        if (modOpt.isEmpty() || pOpt.isEmpty() || ppOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Module mod = modOpt.get();
        Part p = pOpt.get();
        PartPassport pp = ppOpt.get();

        if (!mod.getPartIds().contains(partId)) {
            mod.getPartIds().add(partId);
            moduleRepository.save(mod);
        }

        pp.setCurrentModuleId(moduleId);
        p.setStatus("Integrated");
        partRepository.save(p);

        Event evt = Event.builder()
                .eventType("Integrated")
                .timestamp(new Date())
                .remarks("Integrated into module: " + mod.getName() + " (" + mod.getType() + ")")
                .statusAfterEvent("Integrated")
                .build();
        pp.getEvents().add(evt);
        partPassportRepository.save(pp);

        log.info("[AUDIT] Part {} integrated into module {} ({})", partId, moduleId, mod.getName());

        return ResponseEntity.ok(mod);
    }

    // dropping modules

    @DeleteMapping
    public ResponseEntity<String> dropModulesCollection() {
        log.info("[ADMIN] Dropping modules collection");
        mongoTemplate.dropCollection(Module.class);
        return ResponseEntity.ok("Modules collection dropped successfully.");
    }
}
