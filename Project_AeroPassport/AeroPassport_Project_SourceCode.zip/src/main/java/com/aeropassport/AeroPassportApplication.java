package com.aeropassport;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AeroPassportApplication {

	public static void main(String[] args) {
		SpringApplication.run(AeroPassportApplication.class, args);
	}

}
