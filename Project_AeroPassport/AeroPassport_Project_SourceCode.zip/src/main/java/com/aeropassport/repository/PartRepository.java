package com.aeropassport.repository;

import com.aeropassport.model.Part;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PartRepository extends MongoRepository<Part, String> {
    List<Part> findBySupplierId(String supplierId);
    List<Part> findByBatchNumber(String batchNumber);
}
