package com.aeropassport.repository;

import com.aeropassport.model.PartPassport;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PartPassportRepository extends MongoRepository<PartPassport, String> {
    Optional<PartPassport> findByPartId(String partId);
}
