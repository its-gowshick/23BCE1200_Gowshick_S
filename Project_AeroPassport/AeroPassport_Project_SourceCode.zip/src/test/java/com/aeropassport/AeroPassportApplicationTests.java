package com.aeropassport;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AeroPassportApplicationTests {

	@Test
	void contextLoads() {
	}

}
